// api/films/[id].js  —  PUT edit film  |  DELETE hapus film
import { getCollection }  from '../_db.js';
import { requireAdmin, setCors } from '../_auth.js';
import { ObjectId } from 'mongodb';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(200).end();

  const { id } = req.query;

  // Validasi ObjectId
  let oid;
  try { oid = new ObjectId(id); }
  catch { return res.status(400).json({ error: 'ID tidak valid' }); }

  const col = await getCollection('films');

  // ── PUT: update film ────────────────────────────────────────────────────
  if (req.method === 'PUT') {
    if (!requireAdmin(req, res)) return;

    const { title, year, poster, video, desc, rating, type, category, genre } = req.body;

    if (!title || !poster) {
      return res.status(400).json({ error: 'title dan poster wajib diisi' });
    }

    const update = {
      $set: {
        title:     title.trim(),
        year:      year ? String(year) : '',
        poster:    poster.trim(),
        video:     video?.trim() || '',
        desc:      desc?.trim() || '',
        rating:    parseFloat(rating) || 0,
        vote_average: parseFloat(rating) || 0,
        type:      type || 'movie',
        category:  category || 'trending',
        genre:     genre?.trim() || '',
        updatedAt: new Date(),
      }
    };

    const result = await col.findOneAndUpdate(
      { _id: oid },
      update,
      { returnDocument: 'after' }
    );

    if (!result) return res.status(404).json({ error: 'Film tidak ditemukan' });

    return res.status(200).json({ ...result, id: result._id.toString(), isCustom: true });
  }

  // ── DELETE: hapus film ──────────────────────────────────────────────────
  if (req.method === 'DELETE') {
    if (!requireAdmin(req, res)) return;

    const result = await col.deleteOne({ _id: oid });

    if (result.deletedCount === 0) {
      return res.status(404).json({ error: 'Film tidak ditemukan' });
    }

    return res.status(200).json({ success: true, id });
  }

  res.status(405).json({ error: 'Method not allowed' });
}

// api/_db.js  —  shared MongoDB connection (reused across warm Lambda invocations)
import { MongoClient } from 'mongodb';

const uri    = process.env.MONGODB_URI;   // set di Vercel Environment Variables
const dbName = process.env.DB_NAME || 'nontoncihuy';

let cachedClient = null;

export async function connectDB() {
  if (cachedClient) return cachedClient;
  const client = new MongoClient(uri, { serverSelectionTimeoutMS: 5000 });
  await client.connect();
  cachedClient = client;
  return client;
}

export async function getCollection(name = 'films') {
  const client = await connectDB();
  return client.db(dbName).collection(name);
}

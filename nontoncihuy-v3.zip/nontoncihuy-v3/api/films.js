// api/films.js  —  GET semua film  |  POST tambah film
import { getCollection }  from './_db.js';
import { requireAdmin, setCors } from './_auth.js';
import { ObjectId } from 'mongodb';

export default async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') return res.status(200).end();

  const col = await getCollection('films');

  // ── GET: ambil semua film (publik, no auth) ──────────────────────────────
  if (req.method === 'GET') {
    const { category, type, q } = req.query;
    const filter = {};
    if (category) filter.category = category;
    if (type)     filter.type     = type;
    if (q)        filter.title    = { $regex: q, $options: 'i' };

    const films = await col
      .find(filter)
      .sort({ createdAt: -1 })
      .limit(200)
      .toArray();

    // Normalisasi: tambah field yang dipakai frontend
    const normalized = films.map(f => ({
      ...f,
      id: f._id.toString(),
      isCustom: true,
      vote_average: f.rating ?? f.vote_average ?? 0,
      release_date: f.year ? `${f.year}-01-01` : '',
      first_air_date: f.year ? `${f.year}-01-01` : '',
    }));

    return res.status(200).json({ results: normalized, total: normalized.length });
  }

  // ── POST: tambah film baru (butuh auth) ─────────────────────────────────
  if (req.method === 'POST') {
    if (!requireAdmin(req, res)) return;

    const { title, year, poster, video, desc, rating, type, category, genre } = req.body;

    if (!title || !poster) {
      return res.status(400).json({ error: 'title dan poster wajib diisi' });
    }

    const doc = {
      title:     title.trim(),
      year:      year ? String(year) : '',
      poster:    poster.trim(),
      video:     video?.trim() || '',
      desc:      desc?.trim() || '',
      rating:    parseFloat(rating) || 0,
      vote_average: parseFloat(rating) || 0,
      type:      type || 'movie',       // 'movie' | 'serial'
      category:  category || 'trending', // 'trending'|'terbaru'|'top'|'featured'|'serial'
      genre:     genre?.trim() || '',
      isCustom:  true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const result = await col.insertOne(doc);
    return res.status(201).json({ id: result.insertedId.toString(), ...doc });
  }

  res.status(405).json({ error: 'Method not allowed' });
}
